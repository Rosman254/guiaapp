package mz.visaoguia;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.WindowManager;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Locale;

// Casca nativa: mostra a página do Visão Guia, fala (TTS) e ouve (SpeechRecognizer) sem tocar no ecrã.
public class MainActivity extends Activity {
    static final String ENDERECO = "https://rosman254.github.io/guiaapp/appguia.html";
    WebView web;
    TextToSpeech tts;
    SpeechRecognizer rec;
    Handler h = new Handler(Looper.getMainLooper());
    boolean ttsPronto = false, aFalar = false, aEscutar = false, queroEscutar = false, aberto = false;
    ArrayList<String> pendentes = new ArrayList<>();
    String idAtual = "";
    int n = 0;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.addJavascriptInterface(new Ponte(), "Nativo");
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(final PermissionRequest pr) {
                runOnUiThread(() -> pr.grant(pr.getResources()));
            }
            @Override public void onGeolocationPermissionsShowPrompt(String origem, GeolocationPermissions.Callback cb) {
                cb.invoke(origem, true, false);
            }
        });
        tts = new TextToSpeech(this, st -> {
            if (st == TextToSpeech.SUCCESS) {
                int lr = tts.setLanguage(new Locale("pt", "PT"));
                if (lr == TextToSpeech.LANG_MISSING_DATA || lr == TextToSpeech.LANG_NOT_SUPPORTED) tts.setLanguage(new Locale("pt"));
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String id) { }
                    @Override public void onDone(String id) { h.post(() -> fimFala(id)); }
                    @Override public void onError(String id) { h.post(() -> fimFala(id)); }
                });
                ttsPronto = true;
                h.post(() -> {
                    if (!pendentes.isEmpty()) { String ultimo = pendentes.get(pendentes.size() - 1); pendentes.clear(); falar(ultimo); }
                });
            }
        });
        pedirPermissoes();
    }

    void pedirPermissoes() {
        String[] p = { Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA, Manifest.permission.ACCESS_FINE_LOCATION };
        boolean falta = false;
        for (String x : p) if (checkSelfPermission(x) != PackageManager.PERMISSION_GRANTED) falta = true;
        if (falta) requestPermissions(p, 1); else abrir();
    }

    @Override public void onRequestPermissionsResult(int codigo, String[] perms, int[] res) { abrir(); }

    void abrir() { if (aberto) return; aberto = true; web.loadUrl(ENDERECO); }

    void falar(String t) {
        if (!ttsPronto) { pendentes.add(t); return; }
        pararEscuta();
        aFalar = true;
        idAtual = "u" + (n++);
        tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, idAtual);
    }

    void fimFala(String id) {
        if (!id.equals(idAtual)) return;
        aFalar = false;
        if (queroEscutar) h.postDelayed(() -> iniciarEscuta(), 500);
    }

    void iniciarEscuta() {
        if (!queroEscutar || aFalar || aEscutar) return;
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { falar("O reconhecimento de voz não está disponível neste telemóvel."); queroEscutar = false; return; }
        if (rec == null) {
            rec = SpeechRecognizer.createSpeechRecognizer(this);
            rec.setRecognitionListener(new RecognitionListener() {
                public void onReadyForSpeech(Bundle p) { }
                public void onBeginningOfSpeech() { }
                public void onRmsChanged(float v) { }
                public void onBufferReceived(byte[] buf) { }
                public void onEndOfSpeech() { }
                public void onPartialResults(Bundle p) { }
                public void onEvent(int tipo, Bundle p) { }
                public void onError(int e) {
                    aEscutar = false;
                    if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) { queroEscutar = false; return; }
                    int espera = (e == SpeechRecognizer.ERROR_NETWORK || e == SpeechRecognizer.ERROR_SERVER) ? 2500
                            : (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ? 1200 : 300);
                    h.postDelayed(() -> iniciarEscuta(), espera);
                }
                public void onResults(Bundle r) {
                    aEscutar = false;
                    ArrayList<String> l = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (l != null && !l.isEmpty()) enviar(l.get(0));
                    h.postDelayed(() -> iniciarEscuta(), 300);
                }
            });
        }
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-PT");
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
        aEscutar = true;
        rec.startListening(i);
    }

    void pararEscuta() { if (rec != null && aEscutar) rec.cancel(); aEscutar = false; }

    void enviar(String t) {
        web.evaluateJavascript("window.aoOuvirNativo&&window.aoOuvirNativo(" + JSONObject.quote(t) + ")", null);
    }

    class Ponte {
        @JavascriptInterface public void falar(final String t) { h.post(() -> MainActivity.this.falar(t)); }
        @JavascriptInterface public void escutar() { h.post(() -> { queroEscutar = true; iniciarEscuta(); }); }
        @JavascriptInterface public void parar() { h.post(() -> { queroEscutar = false; pararEscuta(); }); }
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (tts != null) tts.shutdown();
        if (rec != null) rec.destroy();
    }
}
